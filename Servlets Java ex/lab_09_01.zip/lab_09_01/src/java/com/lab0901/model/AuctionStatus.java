package com.lab0901.model;

public enum AuctionStatus {
  ACTIVE, ENDED, CANCELLED
}
