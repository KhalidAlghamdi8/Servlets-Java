package com.lab0901.model;

public enum ItemCondition {

  NEW, USED, PARTS;
}